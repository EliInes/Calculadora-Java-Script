window.calculator = new CalcController();



